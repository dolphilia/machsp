//
//  ViewController.m
//  documentbasededitor
//
//  Created by dolphilia on 2016/01/30.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}

@end
