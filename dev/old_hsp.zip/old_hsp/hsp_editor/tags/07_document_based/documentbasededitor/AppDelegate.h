//
//  AppDelegate.h
//  documentbasededitor
//
//  Created by dolphilia on 2016/01/30.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate> {
    
}

// グローバル変数
@property (readwrite, nonatomic) double documentVisibleX;
@property (readwrite, nonatomic) double documentVisibleY;
@property (readwrite, nonatomic) double documentVisibleWidth;
@property (readwrite, nonatomic) double documentVisibleHeight;

@end

