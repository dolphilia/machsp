//
//  MySplitViewDelegate.h
//  documentbasededitor
//
//  Created by dolphilia on 2016/01/31.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#ifndef MySplitViewDelegate_h
#define MySplitViewDelegate_h

#import <Cocoa/Cocoa.h>

@interface MySplitViewDelegate : NSObject <NSSplitViewDelegate>

@end

#endif /* MySplitViewDelegate_h */
