//
//  MySplitView.h
//  documentbasededitor
//
//  Created by dolphilia on 2016/01/31.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#ifndef MySplitView_h
#define MySplitView_h

#import <Cocoa/Cocoa.h>

@interface MyHorizontalSplitView : NSSplitView <NSSplitViewDelegate>

@end

#endif /* MySplitView_h */
