//
//  runCompiler.h
//  documentbasededitor
//
//  Created by dolphilia on 2016/02/26.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#ifndef runCompiler_h
#define runCompiler_h

#include <stdio.h>
static void usage1( void );
int runCompiler( int argc, char *argv[] );
void testCompiler();

#endif /* runCompiler_h */
