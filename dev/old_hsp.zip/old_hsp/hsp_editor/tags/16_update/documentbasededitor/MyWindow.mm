//
//  MyWindow.m
//  documentbasededitor
//
//  Created by dolphilia on 2016/01/31.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MyWindow.h"
#import "AppDelegate.h"
#import "runCompiler.h"

@implementation MyWindow
-(void)awakeFromNib { //ウィンドウ管理用の番号を初期化する
    accessNumber = -1;
}
-(void)setAccessNumber:(int)num { //ウィンドウ管理用の番号をセットする（外部用）
    accessNumber = num;
}
-(IBAction)onButton:(id)sender {
    if ([sender state] == 0) { //トグルボタンの状態
        [[[self.contentViewController.view.subviews objectAtIndex:0].subviews objectAtIndex:1] setHidden:YES];
    }
    else {
        [[[self.contentViewController.view.subviews objectAtIndex:0].subviews objectAtIndex:1] setHidden:NO];
    }
}
-(IBAction)onLaunchApplication:(id)sender { //実行ボタンを押した時
    //Documents/hsptmpディレクトリにテキストを出力する
    //hsptmpディレクトリを作成する
    NSString *docDir = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    BOOL isDirectory;
    NSFileManager* manager = [NSFileManager defaultManager];
    NSString *yoyoDir = [docDir stringByAppendingPathComponent:@"hsptmp"];
    if (![manager fileExistsAtPath:yoyoDir isDirectory:&isDirectory] || !isDirectory) {
        NSError *error = nil;
        [manager createDirectoryAtPath:yoyoDir
           withIntermediateDirectories:NO
                            attributes:nil
                                 error:&error];
        if (error) {
            NSLog(@"Error creating directory path: %@", [error localizedDescription]);
        }
    }
    AppDelegate* global = (AppDelegate *)[[NSApplication sharedApplication] delegate];
    //テキストを出力する
    NSArray *paths = NSSearchPathForDirectoriesInDomains
    (NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *fileName = [NSString stringWithFormat:@"%@/hsptmp/hsptmp.hsp",
                          documentsDirectory];
    NSString *content;
    if(global.globalTexts == nil || accessNumber == -1) {
        content = @"";
    }
    else {
        content = [global.globalTexts objectAtIndex:accessNumber];
    }
    [content writeToFile:fileName atomically:YES encoding:NSUTF8StringEncoding error:nil];
    
    
    //コンパイルする(Documents/hsptmp/hsptmp.hsp -> start.ax)
    char * filename = (char *)[NSHomeDirectory() stringByAppendingString:@"/Documents/hsptmp/hsptmp.hsp"].UTF8String;
    char * axfilename = (char *)[[@"-o" stringByAppendingString:NSHomeDirectory()] stringByAppendingString:@"/Documents/hsptmp/start.ax"].UTF8String;
    char *argv[] = {(char*)"",axfilename,filename};
    runCompiler(3, argv);
    
    
    //hsp.appを実行する
    //ディレクトリの確認 順序：1.Applications -> 2.Home/Applications -> 3.Home -> 4.Desktop -> 5.Downloads -> ...
    NSString* path = @"";

    BOOL isDir = NO;
    BOOL isExists = NO;
    NSFileManager *filemanager = [ NSFileManager defaultManager];
    
    //1.Applications
    path = @"/Applications/hsp.app";
    isExists = [filemanager fileExistsAtPath:path isDirectory:&isDir];
    if(isExists && isDir) {
        [[NSWorkspace sharedWorkspace] launchApplication:path];
        return;
    }
    
    //2.Home/Applications
    path = [NSHomeDirectory() stringByAppendingString:@"/Applications/hsp.app"];
    isExists = [filemanager fileExistsAtPath:path isDirectory:&isDir];
    if(isExists && isDir) {
        [[NSWorkspace sharedWorkspace] launchApplication:path];
        return;
    }

    //3.Home
    path = [NSHomeDirectory() stringByAppendingString:@"/hsp.app"];
    isExists = [filemanager fileExistsAtPath:path isDirectory:&isDir];
    if(isExists && isDir) {
        [[NSWorkspace sharedWorkspace] launchApplication:path];
        return;
    }
    
    //4.Desktop
    path = [NSHomeDirectory() stringByAppendingString:@"/Desktop/hsp.app"];
    isExists = [filemanager fileExistsAtPath:path isDirectory:&isDir];
    if(isExists && isDir) {
        [[NSWorkspace sharedWorkspace] launchApplication:path];
        return;
    }
    
    //5.Downloads
    path = [NSHomeDirectory() stringByAppendingString:@"/Downloads/hsp.app"];
    isExists = [filemanager fileExistsAtPath:path isDirectory:&isDir];
    if(isExists && isDir) {
        [[NSWorkspace sharedWorkspace] launchApplication:path];
        return;
    }

}
-(IBAction)onTerminateApplication:(id)sender { //停止ボタンを押した時
    [self terminateApplicationWithBundleID:@"com.dolphilia.hsp-viewcontroller"];
}
- (BOOL)terminateApplicationWithBundleID:(NSString *)bundleID //アプリケーションを終了する
{
    // For OS X >= 10.6 NSWorkspace has the nifty runningApplications-method.
    if ([[NSWorkspace sharedWorkspace] respondsToSelector:@selector(runningApplications)])
        for (NSRunningApplication *app in [[NSWorkspace sharedWorkspace] runningApplications])
            if ([bundleID isEqualToString:[app bundleIdentifier]])
                return [app terminate];
    
    // If that didn‘t work then try using the apple event method, also works for OS X < 10.6.
    
    AppleEvent event = {typeNull, nil};
    const char *bundleIDString = [bundleID UTF8String];
    
    OSStatus result = AEBuildAppleEvent(kCoreEventClass, kAEQuitApplication, typeApplicationBundleID, bundleIDString, strlen(bundleIDString), kAutoGenerateReturnID, kAnyTransactionID, &event, NULL, "");
    
    if (result == noErr) {
        result = AESendMessage(&event, NULL, kAEAlwaysInteract|kAENoReply, kAEDefaultTimeout);
        AEDisposeDesc(&event);
    }
    return result == noErr;
}
@end