//
//  Document.m
//  documentbasededitor
//
//  Created by dolphilia on 2016/01/30.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#import "Document.h"

@interface Document ()

@end

@implementation Document

- (instancetype)init {
    self = [super init];
    accessNumber=0;
    if (self) {
        // Add your subclass-specific initialization here.

        aController = [[NSStoryboard storyboardWithName:@"Main" bundle:nil] instantiateControllerWithIdentifier:@"Document Window Controller"];
        title = @"Window";
        global = (AppDelegate *)[[NSApplication sharedApplication] delegate];
        if (global.globalTitles==nil) {
            global.globalTitles = [[NSMutableArray alloc] initWithCapacity:0];
        }
        if (global.globalTexts==nil) {
            global.globalTexts = [[NSMutableArray alloc] initWithCapacity:0];
        }
        [global.globalTexts addObject:@"__NULL__"];
    }
    return self;
}

- (void)windowControllerDidLoadNib:(NSWindowController *)_aController {
    [super windowControllerDidLoadNib:_aController];
    // Add any code here that needs to be executed once the windowController has loaded the document's window.
    
}

+ (BOOL)autosavesInPlace {
    return YES;
}

- (void)makeWindowControllers {
    [self addWindowController:aController];
    
    title = [aController window].title;
    [global.globalTitles addObject:title];
    
    [aController window].title = [NSString stringWithFormat:@"%lu", (unsigned long)global.globalTitles.count];
    title = [aController window].title;
    accessNumber = [title intValue]-1;
}

- (NSDocument *)duplicateAndReturnError:(NSError * _Nullable __autoreleasing *)outError {
    //NSLog(@"dup error");
    return self;
}
- (void)duplicateDocument:(id)sender {
    //NSLog(@"dup1");
}
- (void)duplicateDocumentWithDelegate:(id)delegate didDuplicateSelector:(SEL)didDuplicateSelector contextInfo:(void *)contextInfo {
    //NSLog(@"dup2");
}
- (void)lockDocument:(id)sender {
    //NSLog(@"lock1");
}
- (void)lockDocumentWithCompletionHandler:(void (^)(BOOL))completionHandler {
    //NSLog(@"lock2");
}
- (void)lockWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler {
    //NSLog(@"lock3");
}

//-(void)autosaveDocumentWithDelegate:(id)delegate didAutosaveSelector:(SEL)didAutosaveSelector contextInfo:(void *)contextInfo {
//    //ファイルを自動保存する
//}

- (NSData *)dataOfType:(NSString *)typeName error:(NSError **)outError {
    //ファイルを保存する
    
//    if (outError != NULL) {
//    }
    
    NSDictionary * dic;
    //if ([typeName compare:@"public.plain-text"] == NSOrderedSame || [typeName compare:@"com.hsp-source"] == NSOrderedSame ) {
        dic = [NSDictionary dictionaryWithObjectsAndKeys:
                 NSPlainTextDocumentType,
                 NSDocumentTypeDocumentAttribute,nil];
    //} else {
    //    NSLog(@"ERROR: dataOfType pTypeName=%@",typeName);
    //    *outError = [NSError errorWithDomain:NSOSStatusErrorDomain
    //                                     code:unimpErr
    //                                 userInfo:NULL];
    //    return NULL;
    //}
    NSString * str = [global.globalTexts objectAtIndex:accessNumber];//@"";
    
    //NSData * data = [str dataUsingEncoding:NSASCIIStringEncoding];
    NSData* data = [str dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
    //NSLog(@"%@",str);
    //NSData* data = [str dataUsingEncoding:NSShiftJISStringEncoding allowLossyConversion:YES];// 強制的に変換する
    //NSLog(@"%@",data);
    return data;
}

- (BOOL)readFromData:(NSData *)data ofType:(NSString *)typeName error:(NSError **)outError {
    //ファイルを開く
    
    if (outError != NULL) {
    }
    
//    if ([typeName compare:@"public.plain-text"] != NSOrderedSame || [typeName compare:@"com.hsp-source"] != NSOrderedSame) {
//        NSLog(@"エラーが発生しました:%@",typeName);
//        return NO;
//    }
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                           NSPlainTextDocumentType,
                           NSDocumentTypeDocumentAttribute,
                           nil];
    NSDictionary *attr;
    NSError *error = nil;
    NSAttributedString * zNSAttributedStringObj =
    [[NSAttributedString alloc]initWithData:data
                                    options:dic
                         documentAttributes:&attr
                                      error:&error];
    if ( error != NULL ) {
        NSLog(@"Error readFromData: %@",[error localizedDescription]);
        return NO;
    }

    [[[NSOperationQueue alloc] init] addOperationWithBlock:^{
        while(YES) {
            if ([title isEqual:@"Window"]) {
            }
            else {
                [global.globalTexts replaceObjectAtIndex:[title intValue]-1 withObject:[zNSAttributedStringObj string]];
                break;
            }
            usleep(100000);
        }
    }];
    
    return YES;
}

@end
