//
//  MyWindow.m
//  documentbasededitor
//
//  Created by dolphilia on 2016/01/31.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MyWindow.h"

@implementation MyWindow
-(IBAction)onButton:(id)sender {
    if ([sender state] == 0) { //トグルボタンの状態
        [[[self.contentViewController.view.subviews objectAtIndex:0].subviews objectAtIndex:1] setHidden:YES];
    }
    else {
        [[[self.contentViewController.view.subviews objectAtIndex:0].subviews objectAtIndex:1] setHidden:NO];
    }
}
@end