//
//  MyStatusBarLabel.h
//  documentbasededitor
//
//  Created by dolphilia on 2016/02/18.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#ifndef MyStatusBarLabel_h
#define MyStatusBarLabel_h

#import <Cocoa/Cocoa.h>
#import "AppDelegate.h"

@interface MyStatusBarLabel : NSTextField {
    AppDelegate* global;
}

@end

#endif /* MyStatusBarLabel_h */
