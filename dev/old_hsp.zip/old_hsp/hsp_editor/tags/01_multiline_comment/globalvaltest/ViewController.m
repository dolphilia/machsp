//
//  ViewController.m
//  globalvaltest
//
//  Created by dolphilia on 2016/01/26.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];
    
    // Update the view, if already loaded.
}

@end
