//
//  main.m
//  globalvaltest
//
//  Created by dolphilia on 2016/01/26.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
