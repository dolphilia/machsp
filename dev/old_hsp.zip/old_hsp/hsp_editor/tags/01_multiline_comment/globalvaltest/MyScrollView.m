//
//  MyScrollView.m
//  nstextview-fontcolor-test
//
//  Created by dolphilia on 2016/01/25.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MyScrollView.h"

@implementation MyScrollView

- (instancetype)init
{
    self = [super init];
    if (self) {
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    global = (AppDelegate *)[[NSApplication sharedApplication] delegate];
    if (self) {
        //マルチスレッドで随時、コンテンツの表示位置を格納
        [[[NSOperationQueue alloc] init] addOperationWithBlock:^{
            while (YES) {
                global.documentVisibleX = self.contentView.documentVisibleRect.origin.x;
                global.documentVisibleY = self.contentView.documentVisibleRect.origin.y;
                global.documentVisibleWidth = self.contentView.documentVisibleRect.size.width;
                global.documentVisibleHeight = self.contentView.documentVisibleRect.size.height;
                usleep(100000);
            }
        }];
    }
    return self;
}

- (instancetype)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //NSLog(@"init frame");
    }
    return self;
}

@end