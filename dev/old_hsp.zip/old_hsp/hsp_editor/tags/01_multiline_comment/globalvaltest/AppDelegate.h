//
//  AppDelegate.h
//  globalvaltest
//
//  Created by dolphilia on 2016/01/26.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface AppDelegate : NSObject <NSApplicationDelegate> {
}

// グローバル変数
@property (readwrite, nonatomic) double documentVisibleX;
@property (readwrite, nonatomic) double documentVisibleY;
@property (readwrite, nonatomic) double documentVisibleWidth;
@property (readwrite, nonatomic) double documentVisibleHeight;

@property (nonatomic, retain) NSString *globalString;
@property (strong, nonatomic) NSMutableDictionary *globalDictionary;


@end

