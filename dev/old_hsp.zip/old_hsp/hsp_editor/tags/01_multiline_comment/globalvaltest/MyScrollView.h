//
//  MyScrollView.h
//  nstextview-fontcolor-test
//
//  Created by dolphilia on 2016/01/25.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#ifndef MyScrollView_h
#define MyScrollView_h

#import <Cocoa/Cocoa.h>
#import <AppKit/AppKit.h>
#import "AppDelegate.h"

@interface MyScrollView : NSScrollView {
    AppDelegate* global;
}

@end

#endif /* MyScrollView_h */
