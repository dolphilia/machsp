//
//  MyWindow.m
//  documentbasededitor
//
//  Created by dolphilia on 2016/01/31.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MyWindow.h"
#import "AppDelegate.h"

@implementation MyWindow
-(void)awakeFromNib { //ウィンドウ管理用の番号を初期化する
    accessNumber = -1;
}
-(void)setAccessNumber:(int)num { //ウィンドウ管理用の番号をセットする（外部用）
    accessNumber = num;
}
-(IBAction)onButton:(id)sender {
    if ([sender state] == 0) { //トグルボタンの状態
        [[[self.contentViewController.view.subviews objectAtIndex:0].subviews objectAtIndex:1] setHidden:YES];
    }
    else {
        [[[self.contentViewController.view.subviews objectAtIndex:0].subviews objectAtIndex:1] setHidden:NO];
    }
}
-(IBAction)onLaunchApplication:(id)sender { //実行ボタンを押した時
    //printf("launch");
    NSString* path = @"";
    path = [path stringByAppendingString:NSHomeDirectory()];
    path = [path stringByAppendingString:@"/Desktop/hsp.app"];
    [[NSWorkspace sharedWorkspace] launchApplication:path];
    
    //hsptmpディレクトリを作成する
    NSString *docDir = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    //NSLog(@"docDir is yoyo :: %@", docDir);
    //NSString *FilePath = [docDir stringByAppendingPathComponent:@"yoyo.txt"];
    BOOL isDirectory;
    NSFileManager* manager = [NSFileManager defaultManager];
    NSString *yoyoDir = [docDir stringByAppendingPathComponent:@"hsptmp"];
    if (![manager fileExistsAtPath:yoyoDir isDirectory:&isDirectory] || !isDirectory) {
        NSError *error = nil;
        //NSDictionary *attr = [NSDictionary dictionaryWithObject:NSFileProtectionComplete
        //                                                 forKey:NSFileProtectionKey];
        [manager createDirectoryAtPath:yoyoDir
           withIntermediateDirectories:NO
                            attributes:nil
                                 error:&error];
        if (error) {
            NSLog(@"Error creating directory path: %@", [error localizedDescription]);
        }
    }
    
    AppDelegate* global = (AppDelegate *)[[NSApplication sharedApplication] delegate];
    
    
    //hsptmpディレクトリにテキストを出力する
    //get the documents directory:
    NSArray *paths = NSSearchPathForDirectoriesInDomains
    (NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    //make a file name to write the data to using the documents directory:
    NSString *fileName = [NSString stringWithFormat:@"%@/hsptmp/hsptmp.hsp",
                          documentsDirectory];
    //create content - four lines of text
    NSString *content;
    
    if(global.globalTexts == nil || accessNumber == -1) {
        content = @"";
    }
    else {
        content = [global.globalTexts objectAtIndex:accessNumber];//@"One\nTwo\nThree\nFour\nFive";
    }
    //save content to the documents directory
    [content writeToFile:fileName
              atomically:NO
                encoding:NSStringEncodingConversionAllowLossy
                   error:nil];
    
    //printf("%d",accessNumber);
    
}
-(IBAction)onTerminateApplication:(id)sender { //停止ボタンを押した時
    [self terminateApplicationWithBundleID:@"com.dolphilia.hsp-viewcontroller"];
}
- (BOOL)terminateApplicationWithBundleID:(NSString *)bundleID //アプリケーションを終了する
{
    // For OS X >= 10.6 NSWorkspace has the nifty runningApplications-method.
    if ([[NSWorkspace sharedWorkspace] respondsToSelector:@selector(runningApplications)])
        for (NSRunningApplication *app in [[NSWorkspace sharedWorkspace] runningApplications])
            if ([bundleID isEqualToString:[app bundleIdentifier]])
                return [app terminate];
    
    // If that didn‘t work then try using the apple event method, also works for OS X < 10.6.
    
    AppleEvent event = {typeNull, nil};
    const char *bundleIDString = [bundleID UTF8String];
    
    OSStatus result = AEBuildAppleEvent(kCoreEventClass, kAEQuitApplication, typeApplicationBundleID, bundleIDString, strlen(bundleIDString), kAutoGenerateReturnID, kAnyTransactionID, &event, NULL, "");
    
    if (result == noErr) {
        result = AESendMessage(&event, NULL, kAEAlwaysInteract|kAENoReply, kAEDefaultTimeout);
        AEDisposeDesc(&event);
    }
    return result == noErr;
}
@end