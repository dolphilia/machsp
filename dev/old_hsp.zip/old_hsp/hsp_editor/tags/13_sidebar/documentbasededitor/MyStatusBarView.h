//
//  MyStatusBarView.h
//  documentbasededitor
//
//  Created by dolphilia on 2016/02/20.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#ifndef MyStatusBarView_h
#define MyStatusBarView_h

#import <Cocoa/Cocoa.h>
#import "AppDelegate.h"

@interface MyStatusBarView : NSView {
    AppDelegate* global;
}

@end

#endif /* MyStatusBarView_h */
