//
//  MyWebKitView.h
//  documentbasededitor
//
//  Created by dolphilia on 2016/02/20.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#ifndef MyWebKitView_h
#define MyWebKitView_h

#import <Cocoa/Cocoa.h>
#import <WebKit/WebKit.h>

@interface MyWebKitView : WebView {
    
}

@end

#endif /* MyWebKitView_h */
