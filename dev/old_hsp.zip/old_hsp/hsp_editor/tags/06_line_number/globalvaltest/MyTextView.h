//
//  MyTextView.h
//  nstextview-fontcolor-test
//
//  Created by dolphilia on 2016/01/25.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#ifndef MyTextView_h
#define MyTextView_h

#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>
#import "AppDelegate.h"
#import "NSTextViewExtension.h"

@interface MyTextView : NSTextViewExtension {
    AppDelegate* global;
}
-(void)resetTextColor;
-(void)updateTextColor;
@end

#endif /* MyTextView_h */
