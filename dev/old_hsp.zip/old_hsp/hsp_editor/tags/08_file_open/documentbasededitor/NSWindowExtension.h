//
//  MyWindow.h
//  documentbasededitor
//
//  Created by dolphilia on 2016/01/31.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#ifndef MyWindow_h
#define MyWindow_h

#import <Cocoa/Cocoa.h>

@interface NSWindow() {
}

@end

#endif /* MyWindow_h */
