//
//  Document.h
//  documentbasededitor
//
//  Created by dolphilia on 2016/01/30.
//  Copyright © 2016年 dolphilia. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "AppDelegate.h"
#import "MyTextView.h"
#import "NSWindowExtension.h"

@interface Document : NSDocument {
    AppDelegate* global;
    IBOutlet MyTextView* myTextView;
    NSString* title;
    NSWindowController* aController;
}


@end

